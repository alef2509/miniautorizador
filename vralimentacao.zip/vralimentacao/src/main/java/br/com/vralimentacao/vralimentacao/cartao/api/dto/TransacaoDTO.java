package br.com.vralimentacao.vralimentacao.cartao.api.dto;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.math.BigDecimal;

@Data
public class TransacaoDTO {

    @Size(min = 13, max = 16)
    private String numero;


    @NotNull
    @NotBlank
    @Size(min = 6, max = 6)
    private String senha;

    @NotNull
    private BigDecimal valor;
}
