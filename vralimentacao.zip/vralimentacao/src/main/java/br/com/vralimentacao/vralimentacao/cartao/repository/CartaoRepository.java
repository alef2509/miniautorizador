package br.com.vralimentacao.vralimentacao.cartao.repository;

import br.com.vralimentacao.vralimentacao.cartao.exception.CartaoNaoEncontradoException;
import br.com.vralimentacao.vralimentacao.cartao.model.Cartao;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.LockModeType;
import java.util.Optional;

@Repository
@Transactional(readOnly = true)
public interface CartaoRepository extends JpaRepository<Cartao, String> {

    @Override
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    Optional<Cartao> findById(String id);

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    default Cartao findByIdOrThrowNotFound(String id) {
        return findById(id).orElseThrow(CartaoNaoEncontradoException::new);
    }
}
