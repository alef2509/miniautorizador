package br.com.vralimentacao.vralimentacao.cartao.api;

import br.com.vralimentacao.vralimentacao.cartao.api.dto.CartaoFormDTO;
import br.com.vralimentacao.vralimentacao.cartao.api.dto.TransacaoDTO;
import br.com.vralimentacao.vralimentacao.cartao.api.dto.TransacaoResponseDTO;
import br.com.vralimentacao.vralimentacao.cartao.exception.CartaoJaRegistradoException;
import br.com.vralimentacao.vralimentacao.cartao.model.Cartao;
import br.com.vralimentacao.vralimentacao.cartao.service.CartaoService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.util.UriComponentsBuilder;

import javax.transaction.Transactional;
import javax.validation.Valid;
import java.util.List;

@RestController
@AllArgsConstructor
@RequestMapping(path = CartaoController.PATH, produces = { MediaType.APPLICATION_JSON_VALUE })
@Api(value = "Cartao")
public class CartaoController {
    public static final String PATH = "api/vralimentacao";

    @Autowired
    private CartaoService cartaoService;

    @ApiOperation(value = "Cadastrar Novo Cartão")
    @PostMapping("/salvar")

    public ResponseEntity<CartaoFormDTO> cadastrar(@RequestBody @Valid CartaoFormDTO cartaoFormDto, UriComponentsBuilder uriBuilder)
    {
        HttpHeaders responseHeaders = new HttpHeaders();
        try {
            cartaoService.handle(cartaoFormDto);
        } catch (CartaoJaRegistradoException ex) {

            return new ResponseEntity<CartaoFormDTO>(cartaoFormDto, responseHeaders, HttpStatus.UNPROCESSABLE_ENTITY);
        }

        return new ResponseEntity<CartaoFormDTO>(cartaoFormDto, responseHeaders, HttpStatus.CREATED);
    }

    @ApiOperation(value = "Consultar Cartão")
    @GetMapping("/consultar/{numero}")
    public ResponseEntity<Cartao> consultar(@PathVariable String numero){
        HttpHeaders responseHeaders = new HttpHeaders();
        Cartao cartao = cartaoService.handle(numero);
        return new ResponseEntity<Cartao>(cartao, responseHeaders, HttpStatus.OK);
    };


    @ApiOperation(value = "Cadastrar Nova Transação")
    @PostMapping("/efetuarTransacao")

    public ResponseEntity<TransacaoResponseDTO> efetuarTransacao(@RequestBody @Valid TransacaoDTO transacaoDTO, UriComponentsBuilder uriBuilder)
    {
        HttpHeaders responseHeaders = new HttpHeaders();
        TransacaoResponseDTO response = cartaoService.handle(transacaoDTO);
        if (response.getResultado() != "Efetuado com Sucesso")
        {
            return new ResponseEntity<TransacaoResponseDTO>(response, responseHeaders, HttpStatus.UNPROCESSABLE_ENTITY);
        }

        return new ResponseEntity<TransacaoResponseDTO>(response, responseHeaders, HttpStatus.CREATED);
    }


}
