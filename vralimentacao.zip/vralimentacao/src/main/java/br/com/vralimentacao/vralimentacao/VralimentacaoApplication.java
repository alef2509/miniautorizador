package br.com.vralimentacao.vralimentacao;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VralimentacaoApplication {

    public static void main(String[] args) {
        SpringApplication.run(VralimentacaoApplication.class, args);
    }

}
