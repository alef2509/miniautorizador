package br.com.vralimentacao.vralimentacao.cartao.exception;

public class CartaoJaRegistradoException extends RuntimeException {

    private static final long serialVersionUID = -6237420991197291008L;

}
