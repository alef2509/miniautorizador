package br.com.vralimentacao.vralimentacao.cartao.api.dto;

import lombok.Builder;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.math.BigDecimal;

@Data
@Builder
public class TransacaoResponseDTO {

    @NotNull
    private String id_transacao;

    @Size(min = 13, max = 16)
    private String numeroCartao;

    @NotNull
    @NotBlank
    private String resultado;

}
