package br.com.vralimentacao.vralimentacao.cartao.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.DynamicUpdate;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.math.BigDecimal;
import java.time.LocalDate;

@Data
@Builder
@Entity
@NoArgsConstructor
@AllArgsConstructor
@DynamicUpdate
@Table(name = "cartao")
public class Cartao {
    @Id
    @Size(min = 13, max = 16)
    private String numero;

    @NotNull
    @NotBlank
    private String titular;

    @NotNull
    @NotBlank
    @Size(min = 6, max = 6)
    private String senha;

    private BigDecimal saldo;


}
