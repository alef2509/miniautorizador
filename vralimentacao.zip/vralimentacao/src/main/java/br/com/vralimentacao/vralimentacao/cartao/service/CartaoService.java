package br.com.vralimentacao.vralimentacao.cartao.service;

import br.com.vralimentacao.vralimentacao.cartao.api.dto.CartaoFormDTO;
import br.com.vralimentacao.vralimentacao.cartao.api.dto.TransacaoDTO;
import br.com.vralimentacao.vralimentacao.cartao.api.dto.TransacaoResponseDTO;
import br.com.vralimentacao.vralimentacao.cartao.exception.CartaoJaRegistradoException;
import br.com.vralimentacao.vralimentacao.cartao.exception.CartaoNaoEncontradoException;
import br.com.vralimentacao.vralimentacao.cartao.model.Cartao;
import br.com.vralimentacao.vralimentacao.cartao.repository.CartaoRepository;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.math.BigDecimal;
import java.util.Optional;
import java.util.UUID;

@Service
@Transactional
@AllArgsConstructor
public class CartaoService {

    @Autowired
    private final CartaoRepository repository;

    public void handle(final CartaoFormDTO dto) {

        var cartaoexistente =  repository.findById(dto.getNumero());
        if(cartaoexistente.isPresent()){
            throw new CartaoJaRegistradoException();
        }


        var cartao = Cartao.builder()
                .numero(dto.getNumero())
                .titular(dto.getTitular())
                .senha(dto.getSenha())
                .saldo(BigDecimal.valueOf(500))
                .build();

        repository.saveAndFlush(cartao);

    }

    public Cartao handle(final String numero) {

        var cartao = repository.findByIdOrThrowNotFound(numero);
          return cartao;
    }

    public TransacaoResponseDTO handle(final TransacaoDTO transacaoDTO) {
        var resultado = "Efetuado com Sucesso";

        var cartaoexiste = repository.findById(transacaoDTO.getNumero());
        if (!cartaoexiste.isPresent()){
            resultado = "Cartão Não existe";
        }

        var cartao = repository.findByIdOrThrowNotFound(transacaoDTO.getNumero());

        if (transacaoDTO.getValor().compareTo(cartao.getSaldo()) == 1) {
            resultado = "Sem Saldo";
        }

        if (!transacaoDTO.getSenha().equals(cartao.getSenha())) {
            resultado = "Sem invalida";
        }

        if (resultado == "Efetuado com Sucesso")
        {
            cartao.setSaldo(cartao.getSaldo().subtract(transacaoDTO.getValor()));
            repository.saveAndFlush(cartao);
        }



        return  TransacaoResponseDTO.builder()
                .numeroCartao(transacaoDTO.getNumero())
                .id_transacao(UUID.randomUUID().toString())
                .resultado(resultado)
                .build();

    }

}
