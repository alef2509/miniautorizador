package br.com.vralimentacao.vralimentacao.cartao.exception;

public class CartaoNaoEncontradoException extends RuntimeException {

    private static final long serialVersionUID = -6237420991197291008L;

}