create table cartao (
                         numero       varchar(16)     not null,
                         titular  varchar(200)     not null,
                         senha VARCHAR(6)  NOT NULL,
                         saldo numeric(18,6) NOT NULL,
                         CONSTRAINT cartao_pkey PRIMARY KEY (numero)
);