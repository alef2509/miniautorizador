url swagger para testes dos endpoints
 http://localhost:8487/swagger-ui.html